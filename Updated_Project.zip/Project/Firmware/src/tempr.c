
/**
 * @file tempr.c
 * @brief Temperature sensor handling using LM35
 */

#include "main.h"
#include "tempr.h"
#include "adc.h"

/**
 * @brief Read temperature from the LM35 sensor
 * Retrieves ADC value, converts to voltage, and calculates temperature in Celsius.
 * 
 * @return float Temperature in Celsius
 */
float read_temperature(void)
{
    uint16_t adc_value = get_adc(0); // Retrieve ADC value from channel 0
    float voltage = (adc_value * 5.0) / 1023; // Convert ADC value to voltage (5V reference, 10-bit resolution)
    return voltage * 100; // Convert voltage to temperature (10mV/°C for LM35)
}
