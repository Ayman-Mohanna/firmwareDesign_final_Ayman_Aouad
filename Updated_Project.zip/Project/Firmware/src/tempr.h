
/**
 * @file        tempr.h
 * @brief       Temperature sensor handling using LM35
 */

#ifndef TEMPR_H
#define TEMPR_H

#define MAX_TEMPERATURE     (100.0)   /* Maximum measurable temperature (°C) */

/* Function prototypes */
/**
 * @brief Read temperature from the LM35 sensor
 * 
 * Retrieves the ADC value, converts it to voltage, and calculates the
 * temperature in degrees Celsius. Assumes a 5V ADC reference and LM35 sensor
 * specifications (10mV/°C).
 * 
 * @return float Temperature in degrees Celsius
 */
float read_temperature(void);

#endif /* TEMPR_H */
