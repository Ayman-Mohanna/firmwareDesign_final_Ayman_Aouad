
#include "main.h"
#include "timer.h"

// Globals
cntr_size_t local_sys_tick_counter  = 0; // Tick counter

/**
 * ISR for TIMER1 in order to generate a 1ms local_sys_tick
 * This is critical for scheduling tasks and delay operations.
 */
#int_TIMER1
void TIMER1_isr(void)
{
    set_timer1(get_timer1() - TMR1Reload);  /* Re-load timer */
    local_sys_tick_counter++;
}

/**
 * Function to return system ticks counter in ms, passed to scheduler
 * Used for time-based task execution and delays.
 * 
 * @return cntr_size_t system ticks count in ms
 */
cntr_size_t get_ticks_counter(void)
{
    return local_sys_tick_counter;
}

/**
 * Function to implement delay in milliseconds
 * Uses the system tick counter for accurate timing.
 * 
 * @param ms Delay duration in milliseconds
 */
void delay_ms(cntr_size_t ms)
{
    cntr_size_t start_tick = get_ticks_counter();
    while ((get_ticks_counter() - start_tick) < ms);
}
