
#include "main.h"
#include "hardware.h"
#include "system.h"
#include "stdlib.h"

// Global vars
system_info current_system_info = {
    .current_floor = 0, // Default to ground floor (GF)
    .motor_state = MOTOR_STOPPED,
    .direction = DIRECTION_UP
};

/**
 * Initialize system configurations and enable interrupts
 * 
 * @return bool Success or failure
 */
bool init_system(void)
{
    bool ret = true;

    /* Enable TIMER1 interrupt (used for scheduler's 1ms tick) */
    enable_interrupts(INT_TIMER1);
    enable_interrupts(GLOBAL); /* Enable global interrupt */

    /* Initialize system information */
    init_system_info();

    return ret;
}

/**
 * Initialize system information (e.g., defaults for floor, motor state)
 */
void init_system_info(void)
{
    current_system_info.current_floor = 0; // Start at ground floor (GF)
    current_system_info.motor_state = MOTOR_STOPPED;
    current_system_info.direction = DIRECTION_UP;
}

/**
 * Fill system parameters dynamically (placeholder for future expansion)
 */
void fill_system_params(void)
{
    // Example: Update current floor and motor state dynamically
    current_system_info.current_floor = read_current_floor();
    current_system_info.motor_state = get_motor_state();
}

/**
 * Retrieve the current floor based on sensor data
 * 
 * @return int Current floor number (0 = GF, 1 = F1, etc.)
 */
int read_current_floor(void)
{
    // Placeholder: Add logic to read floor sensors and determine the current floor
    return 0; // Default to ground floor
}

/**
 * Retrieve the current motor state (running, stopped, etc.)
 * 
 * @return motor_state_t Current motor state
 */
motor_state_t get_motor_state(void)
{
    // Placeholder: Add logic to determine motor state based on hardware feedback
    return MOTOR_STOPPED;
}
