
#include "main.h"
#include "adc.h"
#include "scheduler.h"

void sample_next_adc_ch(s_task_handle_t me, s_task_msg_t **msg, void* arg);

/* List ADC channels */
uint8_t adc_channels[MAX_ADC_CHANNELS] = {0};	// JUST ONE CHANNEL FOR THIS APP (LM35)
adc_info_t adc_info[MAX_ADC_CHANNELS];

/**
 * Initialize ADC for LM35 sensor
 * Configures ADC ports, channels, and creates a sampling task.
 * 
 * @return bool Initialization success or failure
 */
bool init_adc(void)
{
	uint8_t adc_index;

	/* Analog configuration */
    setup_adc_ports(sAN0, VSS_VDD); // Configure AN0 for LM35 sensor
    setup_adc(ADC_CLOCK_DIV_64 | ADC_TAD_MUL_8);
	set_adc_channel(adc_channels[0]);	/* Select 1st channel */

	/* Reset ADC channel info */
	for (adc_index = 0; adc_index < MAX_ADC_CHANNELS; adc_index++)
	{
		adc_info[adc_index].window_index = 0;	/* Reset index */
	}

	/* Create a task to sample ADC data every 100ms */
	return s_task_create(true, S_TASK_LOW_PRIORITY, 100, sample_next_adc_ch, NULL, NULL);
}

/**
 * Get ADC value for a specific channel
 * 
 * @param chan_index Index of the ADC channel
 * @return uint16_t Average ADC value for the channel
 */
uint16_t get_adc(uint8_t chan_index)
{
	return adc_info[chan_index].average_value;
}

/**
 * Convert ADC value to temperature in Celsius
 * Assumes LM35 output (10mV/°C) with a 5V ADC reference and 10-bit resolution.
 * 
 * @param adc_value ADC value
 * @return float Temperature in Celsius
 */
float adc_to_temperature(uint16_t adc_value)
{
    float voltage = (adc_value * 5.0) / 1023; // Convert ADC value to voltage
    return voltage * 100; // Convert voltage to temperature (10mV/°C)
}

/**
 * Periodic task to sample ADC channel(s)
 * Collects ADC data and updates average values.
 * 
 * @param me Task handle
 * @param msg Task message
 * @param arg Additional arguments
 */
void sample_next_adc_ch(s_task_handle_t me, s_task_msg_t **msg, void* arg)
{
	uint16_t adc_value = read_adc(); // Read current ADC value
	adc_info[0].average_value = adc_value; // Update channel 0 with new value
}
