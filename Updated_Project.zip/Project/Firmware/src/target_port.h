
/**
 * @file        target_port.h
 * @brief       Platform-specific configurations and hardware definitions
 */

#ifndef TARGET_PORT_H
#define TARGET_PORT_H

/* Specify target compiler/processor */
#if (defined (__PCH__) || defined (__PCD__))    /* CCS C compiler */
    #include "stdbool.h"
    #include <stdint.h>
    typedef signed int8      sint8_t;
    typedef signed int16     sint16_t;
    typedef signed int32     sint32_t;
    typedef uint32_t         cntr_size_t;
    #include <stdlibm.h>
    #include <string.h>
#elif defined (__NIOS2__)    /* NIOS */
    #include "alt_types.h"
    #include "stdbool.h"
    typedef alt_u8           uint8_t; 
    typedef alt_8            sint8_t; 
    typedef alt_u16          uint16_t;
    typedef alt_16           sint16_t;
    typedef alt_u32          uint32_t;
    typedef alt_32           sint32_t;
    typedef uint32_t         cntr_size_t;
#else
    #error "Unsupported target platform"
#endif

/* Hardware-specific macros */
/* Motor control pins */
#define PIN_MOTOR_SPEED_HIGH    PIN_B0
#define PIN_MOTOR_SPEED_LOW     PIN_B1
#define PIN_MOTOR_DIR_UP        PIN_B2
#define PIN_MOTOR_DIR_DOWN      PIN_B3

/* LED indicators */
#define PIN_HEARTBEAT_LED       PIN_C1
#define PIN_FLOOR_LED_UP        PIN_C2
#define PIN_FLOOR_LED_DOWN      PIN_C3

/* ADC channel for LM35 */
#define LM35_ADC_CHANNEL        0

/* Button inputs */
#define PIN_FLOOR0_BUTTON_UP    PIN_D0
#define PIN_FLOOR1_BUTTON_UP    PIN_D1
#define PIN_FLOOR1_BUTTON_DOWN  PIN_D2
#define PIN_FLOOR2_BUTTON_UP    PIN_D3
#define PIN_FLOOR2_BUTTON_DOWN  PIN_D4
#define PIN_FLOOR3_BUTTON_DOWN  PIN_D5

#endif /* TARGET_PORT_H */
