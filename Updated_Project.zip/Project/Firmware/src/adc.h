
/**
 * @file        adc.h
 * @brief       ADC-related functionalities and configurations
 */

#ifndef ADC_H
#define ADC_H

/* ADC Configurations */
#define ADC_VREF                (5.0)       /* ADC reference voltage (V) */
#define ADC_MAX_LVL             (1024)      /* Maximum ADC level (10-bit resolution) */
#define ADC_LSB                 (ADC_VREF / ADC_MAX_LVL) /* Voltage per ADC step */

#define MAX_ADC_CHANNELS        1           /* Number of ADC channels */
#define ADC_WINDOW_SIZE         8           /* Sliding window size (must be power of 2) */
#define ADC_WINDOW_SIZE_MASK    (ADC_WINDOW_SIZE - 1) /* Mask for window size */
#define ADC_WINDOW_BIT_SHIFT    3           /* Bit shift for window size (2^3 = 8) */

/* Data structure to hold ADC information */
typedef struct {
    uint16_t current_value;      /* Latest ADC value */
    uint16_t average_value;      /* Average ADC value over the window */
    uint16_t window[ADC_WINDOW_SIZE]; /* Sliding window for averaging */
    uint8_t window_index;        /* Current index in the sliding window */
} adc_info_t;

/* Enumeration for ADC channels */
typedef enum {
    ADC_TEMPR = 0                /* Temperature sensor (LM35) channel */
} adc_chan_t;

/* Function prototypes */
/**
 * @brief Initialize the ADC module
 * 
 * Configures ADC ports and sets up periodic sampling tasks.
 * 
 * @return bool Success or failure
 */
bool init_adc(void);

/**
 * @brief Retrieve the average ADC value for a specific channel
 * 
 * @param chan_index Index of the ADC channel
 * @return uint16_t Averaged ADC value
 */
uint16_t get_adc(uint8_t chan_index);

/**
 * @brief Retrieve the live ADC value for a specific channel
 * 
 * @param chan_index Index of the ADC channel
 * @return uint16_t Latest ADC value (unaveraged)
 */
uint16_t get_adc_live(uint8_t chan_index);

#endif /* ADC_H */
