
/**
 * @file        main.h
 * @brief       Microcontroller and chip-level configurations
 */

#ifndef MAIN_H
#define MAIN_H

#include <18F67K22.h>       /* Microcontroller: PIC18F67K22 */
#device ADC=8              /* ADC resolution in bits */
#device ANSI               /* ANSI C compatibility */

/* Chip configuration */
#FUSES NOWDT               /* Disable Watch Dog Timer */
#FUSES PUT                 /* Enable Power-Up Timer */
#FUSES NOBROWNOUT          /* Disable Brown-Out Reset */
#FUSES BORV20              /* Brown-Out Reset Voltage at 2.0V */

/* Clock and I/O Configuration */
#use delay(internal=64000000)   /* 64 MHz internal clock */
#use I2C(master, slow, I2C1)    /* I2C setup for RTC communication */
#use fast_io(ALL)               /* Enable fast I/O mode */

/* Include hardware and platform configurations */
#include "target_port.h"

#endif /* MAIN_H */
