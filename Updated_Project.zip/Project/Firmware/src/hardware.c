
#include "main.h"
#include "hardware.h"
#include "scheduler.h"

/* Local prototypes */
void heart_beat_led(s_task_handle_t me, s_task_msg_t **msg, void* arg);
void control_motor_speed(bool high_speed);
void control_motor_direction(bool direction_up);

/**
 * @brief Function to setup all IOs
 * Configures ports A to G for input/output as required.
 */
void init_io_ports(void)
{
    set_tris_a(0xFF);    /* A: all inputs */
    output_a(0x00);      /* All ZEROs */

    set_tris_b(0xFF);    /* B: All inputs */
    output_b(0x00);      /* All ZEROs */

    set_tris_c(0xDF);    /* C: all inputs, except RC5 (not used) */
    output_c(0x00);      /* All ZEROs, except EE_WP */

    set_tris_d(0x00);    /* D: all outputs */
    output_d(0x00);      /* All ZEROs */

    set_tris_e(0x00);    /* E: all outputs */
    output_e(0x00);      /* All ZEROs */

    set_tris_f(0x00);    /* F: all outputs */
    output_f(0x00);      /* All ZEROs */

    set_tris_g(0xE0);    /* G: all outputs */
    output_g(0x00);      /* All ZEROs */
}

/**
 * @brief Initialize hardware components
 * 
 * @return bool Success or failure
 */
bool init_hw(void)
{
    init_io_ports();  /* Initialize I/O ports */

    /* Create a heartbeat LED task */
    return s_task_create(true, S_TASK_LOW_PRIORITY, 500, heart_beat_led, NULL, NULL);
}

/**
 * @brief Control motor speed (high/low)
 * 
 * @param high_speed True for high speed, false for low speed
 */
void control_motor_speed(bool high_speed)
{
    if (high_speed)
    {
        output_high(PIN_MOTOR_SPEED_HIGH); // High-speed pin
        output_low(PIN_MOTOR_SPEED_LOW);  // Ensure low-speed pin is off
    }
    else
    {
        output_high(PIN_MOTOR_SPEED_LOW);  // Low-speed pin
        output_low(PIN_MOTOR_SPEED_HIGH); // Ensure high-speed pin is off
    }
}

/**
 * @brief Control motor direction (up/down)
 * 
 * @param direction_up True for up, false for down
 */
void control_motor_direction(bool direction_up)
{
    if (direction_up)
    {
        output_high(PIN_MOTOR_DIR_UP);   // Up direction pin
        output_low(PIN_MOTOR_DIR_DOWN); // Ensure down direction pin is off
    }
    else
    {
        output_high(PIN_MOTOR_DIR_DOWN); // Down direction pin
        output_low(PIN_MOTOR_DIR_UP);   // Ensure up direction pin is off
    }
}

/**
 * @brief Heartbeat LED task
 * Simple task to toggle an LED for system health indication.
 * 
 * @param me Task handle
 * @param msg Task message
 * @param arg Additional arguments
 */
void heart_beat_led(s_task_handle_t me, s_task_msg_t **msg, void* arg)
{
    static bool led_state = false;
    led_state = !led_state;
    if (led_state)
    {
        output_high(PIN_HEARTBEAT_LED);
    }
    else
    {
        output_low(PIN_HEARTBEAT_LED);
    }
}
