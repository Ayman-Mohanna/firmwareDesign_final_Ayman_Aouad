
/**
 * @file        system.h
 * @brief       System-wide functionalities and configurations
 */

#ifndef SYSTEM_H
#define SYSTEM_H

#include <stdint.h>
#include <stdbool.h>

/* Enumeration for motor state */
typedef enum {
    MOTOR_STOPPED,
    MOTOR_RUNNING
} motor_state_t;

/* Enumeration for motor direction */
typedef enum {
    DIRECTION_UP,
    DIRECTION_DOWN
} motor_direction_t;

/* Structure to store system information */
typedef struct {
    int current_floor;           /* Current floor (0 = GF, 1 = F1, etc.) */
    motor_state_t motor_state;   /* Current motor state */
    motor_direction_t direction; /* Current motor direction */
} system_info;

/* Global system information */
extern system_info current_system_info;

/* Function prototypes */
/**
 * @brief Initialize the system, including interrupts and default parameters.
 * 
 * @return bool Success or failure
 */
bool init_system(void);

/**
 * @brief Initialize system information to default values.
 */
void init_system_info(void);

/**
 * @brief Dynamically update system parameters (e.g., floor, motor state).
 */
void fill_system_params(void);

/**
 * @brief Retrieve the current floor based on sensor data.
 * 
 * @return int Current floor number (0 = GF, 1 = F1, etc.)
 */
int read_current_floor(void);

/**
 * @brief Retrieve the current motor state (running, stopped, etc.).
 * 
 * @return motor_state_t Current motor state
 */
motor_state_t get_motor_state(void);

#endif /* SYSTEM_H */
