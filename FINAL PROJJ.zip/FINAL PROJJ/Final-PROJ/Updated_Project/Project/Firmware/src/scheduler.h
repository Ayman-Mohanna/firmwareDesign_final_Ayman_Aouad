
/**
 * @file        scheduler.h
 * @brief       Header file for cooperative scheduler
 */

#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "target_port.h"
#include "scheduler_options.h"

#ifdef USE_MESSAGING
/* Macros for message handling */
#define S_TASK_MSG_READY(m_h)        (m_h)
#define S_TASK_MSG_SRC(m_h)          (m_h->s_task_src_hndl)
#define S_TASK_MSG_DATA_SIZE(m_h)    (m_h->data_size)
#define S_TASK_MSG_DATA(m_h)         (m_h->data)
#define S_TASK_NEXT_MSG(m_h)         {m_h = m_h->next;}
#endif

/* Task handle type */
typedef uint16_t s_task_handle_t;

/* Task Priority enumeration */
typedef enum
{
    S_TASK_LOW_PRIORITY = 0,
    S_TASK_MEDIUM_PRIORITY,
    S_TASK_HIGH_PRIORITY
} s_task_priority_t;

/* Function prototypes */
bool s_task_create(bool active, s_task_priority_t priority, uint16_t interval, void (*task_func)(void), void* arg, void* msg);
void scheduler_init_tasks(void);
void scheduler(void);
void scheduler_yield(void);

#endif /* SCHEDULER_H */
