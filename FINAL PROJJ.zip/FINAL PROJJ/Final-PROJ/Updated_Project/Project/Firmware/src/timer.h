
/**
 * @file        timer.h
 * @brief       Timer-related functionalities for scheduling and delays
 */

#ifndef TIMER_H
#define TIMER_H

#include "scheduler.h"

/* Timer-related definitions */
#define TMR1Reload      2000     /* Timer reload value for 16 MIPS operation */

/* Function prototypes */
/**
 * @brief Retrieve the system tick counter (in milliseconds)
 * 
 * @return cntr_size_t System ticks in ms
 */
cntr_size_t get_ticks_counter(void);

/**
 * @brief Implement a delay in milliseconds
 * 
 * @param ms Delay duration in milliseconds
 */
void delay_ms(cntr_size_t ms);

#endif /* TIMER_H */
