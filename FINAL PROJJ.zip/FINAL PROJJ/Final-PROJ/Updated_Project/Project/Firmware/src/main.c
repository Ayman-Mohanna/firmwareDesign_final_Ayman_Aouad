
#include "main.h"
#include "hardware.h"
#include "system.h"
#include "scheduler.h"
#include "timer.h"
#include "adc.h"
#include "rtc.h" // Added for Real-Time Clock support
#include "lm35.h" // Added for temperature sensor support

void main()
{
    bool ret;
    
    delay_ms(100);                  /*power up delay, wait a 100ms*/

    /* Initialize scheduler */
    ret = scheduler_init(get_ticks_counter);
    
    if (true == ret)
    {
        /* Initialize system components */
        ret &= init_hw();           /*initialize HW and create LED heartbeat task*/
        ret &= init_system();       /*initialize system and enable interrupt(s) (events)*/
        ret &= init_adc();          /*initialize ADC sampling*/
        ret &= init_rtc();          /*initialize RTC*/
        ret &= init_lm35();         /*initialize LM35 temperature sensor*/

        if (true == ret)            /*success?*/
        {
            while (true)
            {
                scheduler();        /*run scheduler forever*/
                display_floor_info(); /* Display current floor info */
                display_cabin_info(); /* Display cabin-specific details (time, date, temperature) */
            }
        }
        else
        {
            while (true);           /*stall*/
        }
    }
    else
    {
        while (true);               /*stall*/
    }
}
