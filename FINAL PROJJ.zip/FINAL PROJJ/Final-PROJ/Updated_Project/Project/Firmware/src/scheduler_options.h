
/**
 * @file        scheduler_options.h
 * @brief       Configuration options for the scheduler
 */

#ifndef SCHEDULER_OPTIONS_H
#define SCHEDULER_OPTIONS_H

/* Enable messaging for inter-task communication */
#define USE_MESSAGING

/* Enable semaphore handling for task synchronization */
#define USE_SEMAPHORE

/* Enable retimed synchronization for optimized dispatching */
#define USE_RETIMER

/* Enable busy LED indication for debugging */
#if (defined (__PCH__) || defined (__PCD__))    /* CCS C compiler? */
#define USE_BUSY_LED
#endif

#ifdef USE_BUSY_LED
#define BLEDON()        output_high(PIN_C1)
#define BLEDOFF()       output_low(PIN_C1)
#endif

#endif /* SCHEDULER_OPTIONS_H */
