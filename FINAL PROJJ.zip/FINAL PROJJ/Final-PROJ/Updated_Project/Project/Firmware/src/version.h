
/**
 * @file        version.h
 * @brief       Firmware version tracking and history
 */

#ifndef VERSION_H
#define VERSION_H

/* Revision history */
#define FW_REV_MAJ     1   /* Major version: Increment for significant updates */
#define FW_REV_MIN     0   /* Minor version: Increment for minor changes or fixes */
#define FW_REV_BLD     1   /* Build number: Increment for each build */

/* Revision date */
#define FW_REV_DAY     10  /* Day of release */
#define FW_REV_MNT     1   /* Month of release */
#define FW_REV_YER     25  /* Year of release (last two digits, e.g., 2025) */

/* Version string (e.g., V1.0.1 - 10/01/25) */
#define FW_VERSION_STR "V1.0.1 - 10/01/25"

/* Notes for this version */
/* 
 * - Initial implementation of elevator controller functionality.
 * - Added support for floor indicators, motor control, and cabin display.
 * - Integrated LM35 temperature sensor and RTC for time and date.
 */

#endif /* VERSION_H */
