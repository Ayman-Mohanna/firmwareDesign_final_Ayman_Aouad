
/**
 * @file        hardware.h
 * @brief       Hardware-related functionalities and configurations
 */

#ifndef HARDWARE_H
#define HARDWARE_H

#include "stdbool.h"    /* In order to use "bool" type */

/* Function prototypes */
/**
 * @brief Initialize hardware components, including I/O ports and tasks
 * 
 * Configures all I/O ports and initializes any hardware-related tasks,
 * such as the heartbeat LED.
 * 
 * @return bool Success or failure
 */
bool init_hw(void);

/**
 * @brief Control motor speed (high/low)
 * 
 * Sets the motor speed to either high or low based on the input parameter.
 * 
 * @param high_speed True for high speed, false for low speed
 */
void control_motor_speed(bool high_speed);

/**
 * @brief Control motor direction (up/down)
 * 
 * Sets the motor direction to either up or down based on the input parameter.
 * 
 * @param direction_up True for up direction, false for down direction
 */
void control_motor_direction(bool direction_up);

#endif /* HARDWARE_H */
