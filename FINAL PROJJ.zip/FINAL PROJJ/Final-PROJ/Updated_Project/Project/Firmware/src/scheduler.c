
/**
 * @file		scheduler.c
 * @brief		Co-operative scheduler
 * @details		Contains co-operative scheduler API for elevator operations
 */

#include "scheduler.h"
#include "hardware.h"
#include "rtc.h"
#include "lm35.h"

/* Define task handles for elevator system */
static void task_floor_indicator(void);
static void task_motor_control(void);
static void task_cabin_display(void);

/* Initialize scheduler tasks */
void scheduler_init_tasks(void)
{
    /* Register tasks with appropriate priorities */
    sTaskCreate(task_floor_indicator, 1); /* Priority 1: Floor Indicators */
    sTaskCreate(task_motor_control, 2);   /* Priority 2: Motor Control */
    sTaskCreate(task_cabin_display, 3);   /* Priority 3: Cabin Display Updates */
}

/* Task: Update floor indicators */
static void task_floor_indicator(void)
{
    while (true)
    {
        update_floor_indicators();
        scheduler_yield(); /* Allow other tasks to execute */
    }
}

/* Task: Motor control for speed and direction */
static void task_motor_control(void)
{
    while (true)
    {
        control_motor_speed();
        control_motor_direction();
        scheduler_yield(); /* Allow other tasks to execute */
    }
}

/* Task: Update cabin display (time, date, temperature) */
static void task_cabin_display(void)
{
    while (true)
    {
        update_cabin_time();
        delay_ms(10000); /* Show time for 10 seconds */
        update_cabin_date();
        delay_ms(10000); /* Show date for 10 seconds */
        update_cabin_temperature();
        delay_ms(10000); /* Show temperature for 10 seconds */
        scheduler_yield(); /* Allow other tasks to execute */
    }
}
